#include "include/common.h"
#include "include/gestione_lavagna.h"
#include "include/protocollo_lavagna.h"

// Stato globale della lavagna
struct Card * lavagna;
struct Utente * lista_utenti;

int32_t main() {
    uint32_t socket_lavagna;                        // File descriptor del socket per le richieste di connessione TCP
    struct sockaddr_in indirizzo_lavagna;           // Indirizzo del server lavagna
    uint32_t addrlen = sizeof(indirizzo_lavagna);   // Lunghezza della struttura in byte

    fd_set descrittori_lettura;                     // Set dei descrittori su cui fare polling
    uint32_t max_socket;                            // Socket con ID massimo
    struct timeval timeout;                         // Parametro per la accept()

    // Inizializzazione card
    for (uint16_t i = 1; i <= NUM_CARD_INIZIALI; i++) {
        char testo[LUNGHEZZA_TESTO];
        sprintf(testo, "Task Iniziale %d", i);
        crea_card(TODO, testo, (i == NUM_CARD_INIZIALI) ? 1 : 0);
    }

    // Indirizzo del server lavagna
    indirizzo_lavagna.sin_family = AF_INET;
    indirizzo_lavagna.sin_addr.s_addr = INADDR_ANY;
    indirizzo_lavagna.sin_port = htons(PORTA_LAVAGNA);

    // Creazione del file descriptor del socket 
    if ((socket_lavagna = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket fallito: ");
        exit(EXIT_FAILURE);
    }

    // SO_REUSEADDR permette di riutilizzare immediatamente la porta 5678 dopo la chiusura del server
    int32_t opt = 1;
    if (setsockopt(socket_lavagna, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("Setsockopt fallito: ");
        close(socket_lavagna);
        exit(EXIT_FAILURE);
    }

    // Bind del socket all'indirizzo
    if (bind(socket_lavagna, (struct sockaddr *)&indirizzo_lavagna, sizeof(indirizzo_lavagna)) < 0) {
        perror("Bind fallito: ");
        close(socket_lavagna);
        exit(EXIT_FAILURE);
    }

    // Socket passivo 
    if (listen(socket_lavagna, 5) < 0) {
        perror("Listen fallita: ");
        close(socket_lavagna);
        exit(EXIT_FAILURE);
    }

    while (1) {
        FD_ZERO(&descrittori_lettura);
        FD_SET(socket_lavagna, &descrittori_lettura);
        max_socket = socket_lavagna;

        // Aggiunge i socket degli utenti già connessi al set e calcola il massimo
        for (struct Utente * utente = lista_utenti; utente; utente = utente->successivo) {
            uint32_t socket_utente = utente->socket_utente;
            if (socket_utente > 0) {
                FD_SET(socket_utente, &descrittori_lettura);
                max_socket = (socket_utente > max_socket) ? socket_utente : max_socket;
            }
        }

        // Configura timeout (es. 1.30 min per PING_USER) 
        timeout.tv_sec = 90; 
        timeout.tv_usec = 0;

        // Polling dei socket
        uint32_t num_descrittori_pronti = select(max_socket + 1, &descrittori_lettura, NULL, NULL, &timeout);
        if (num_descrittori_pronti == (uint32_t)-1) {
            if (errno == EINTR) continue; // Errore non fatale: una chiamata di sistema è stata interrotta
            else { // Errore fatale (es. memoria esaurita o socket non valido)
                perror("Select fallita con errore fatale: ");
                exit(EXIT_FAILURE); 
            }
        }

        // Se select restituisce 0, è passato il tempo limite 
        if (num_descrittori_pronti == 0) {
            // TODO
            // Logica PING_USER: scorri la lista 'lavagna' e controlla i tempi [cite: 46, 81]
            printf("Timeout raggiunto: avvio controllo PING_USER...\n");
            continue;
        }

        // Utente chiede di stabilire una connessione TCP
        if (FD_ISSET(socket_lavagna, &descrittori_lettura)) { // Crea utente o lo inserisce nella lista
            uint32_t socket_utente = accept(socket_lavagna, (struct sockaddr *)&indirizzo_lavagna, &addrlen);
            if (socket_utente > 0) crea_utente(socket_utente);
        }

        // Gestione messaggi dagli utenti
        struct Utente * utente = lista_utenti;
        struct Utente * precedente = NULL; // Utile per rimozione (QUIT)

        while (utente != NULL) {
            if (FD_ISSET(utente->socket_utente, &descrittori_lettura)) {
                struct Messaggio_utente_lavagna msg;
                int32_t bytes_letti = ricevi_messaggio(utente->socket_utente, &msg);

                if (bytes_letti == 0) { // Utente disconnesso
                    distruggi_utente(utente, precedente);
                    show_lavagna();
                    assegna_card(NULL); 
                    continue;
                } 
                else { // Gestione comandi
                    switch (msg.comando_utente) {
                        case CMD_HELLO: // Utente inizia a lavorare
                            attiva_utente(utente, msg.porta_utente);
                            assegna_card(utente);
                            break;

                        case CMD_ACK_CARD: // Utente conferma presa in carico
                            sposta_card(msg.id_card, DOING, utente);
                            break;

                        case CMD_REQUEST_USER_LIST: // Utente chiede lista per fare review
                            invia_lista_utenti(utente);
                            break;

                        case CMD_CARD_DONE: // Utente ha finito, sposta card in DONE e assegna nuova card
                            sposta_card(msg.id_card, DONE, NULL);
                            assegna_card(utente);
                            break;
                            
                        case CMD_CREATE_CARD: // Utente chiede la creazione di una nuova card
                            crea_card((enum Colonne)msg.colonna, msg.testo, 1);
                            assegna_card(NULL); // Assegno all'utente di porta minore
                            break;

                        case CMD_QUIT: // Utente finisce di lavorare
                            disattiva_utente(utente);
                            break;
                    }
                }
            }
            precedente = utente;
            utente = utente->successivo;
        }
    }

    exit(EXIT_SUCCESS);
}