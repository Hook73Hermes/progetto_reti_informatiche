#include "include/common.h"
#include "include/include_utente.h"
#include "include/protocollo_utente.h"

int32_t main() {
    exit(EXIT_SUCCESS);
}